/**
 * MyCrane
 * @constructor
 */
class MyCrane extends CGFobject
{
   constructor(scene) 
   {
       super(scene);
       

   };

   setAngle1(a){
       this.ang = a;
   }


   display() {


   };
};